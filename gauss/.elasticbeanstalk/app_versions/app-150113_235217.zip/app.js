#!/usr/bin/env node
require('coffee-script');
require('./app.coffee');