#!/usr/bin/env node
require('coffee-script/register');
require('./app.coffee');